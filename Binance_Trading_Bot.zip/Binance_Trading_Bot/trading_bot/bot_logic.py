from binance.client import Client
import time
from binance.enums import (
    ORDER_TYPE_MARKET, ORDER_TYPE_LIMIT,
    SIDE_BUY, SIDE_SELL
)
from config import get_binance_client
from logger import setup_logger

class BasicBot:
    def __init__(self):
        self.client = get_binance_client()
        self.logger = setup_logger()

    def place_order(self, symbol, side, order_type, quantity, price=None, stop_price=None, stop_limit_price=None):
        try:
            if order_type == "OCO":
                if not (price and stop_price and stop_limit_price):
                    self.logger.error("OCO order requires limit price, stop price, and stop-limit price.")
                    return None

                # Place a LIMIT order
                limit_order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == "BUY" else SIDE_SELL,
                    type=ORDER_TYPE_LIMIT,
                    timeInForce="GTC",
                    quantity=quantity,
                    price=price
                )

                # Place a simulated STOP_MARKET order
                stop_order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == "BUY" else SIDE_SELL,
                    type="STOP_MARKET",
                    stopPrice=stop_price,
                    quantity=quantity
                )

                self.logger.info("✅ Simulated OCO Order Placed: LIMIT + STOP_MARKET")
                self.logger.info(f"LIMIT Order: {limit_order}")
                self.logger.info(f"STOP_MARKET Order: {stop_order}")
                return {"limit_order": limit_order, "stop_order": stop_order}

            elif order_type == "MARKET":
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == "BUY" else SIDE_SELL,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
                self.logger.info(f"Market Order Placed: {order}")
                return order

            elif order_type == "LIMIT":
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == "BUY" else SIDE_SELL,
                    type=ORDER_TYPE_LIMIT,
                    timeInForce="GTC",
                    quantity=quantity,
                    price=price
                )
                self.logger.info(f"Limit Order Placed: {order}")
                return order

            elif order_type == "STOP_MARKET":
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=SIDE_BUY if side == "BUY" else SIDE_SELL,
                    type="STOP_MARKET",
                    stopPrice=stop_price,
                    quantity=quantity
                )
                self.logger.info(f"Stop Market Order Placed: {order}")
                return order
            elif order_type == "TWAP":
                chunks = 5
                chunk_qty = round(quantity / chunks, 6)
                delay = 5  # seconds between chunks
                self.logger.info(f"Starting TWAP order: {chunks} chunks, {chunk_qty} per order, delay {delay}s")
                for i in range(chunks):
                    try:
                        order = self.client.futures_create_order(
                            symbol=symbol,
                            side=SIDE_BUY if side == "BUY" else SIDE_SELL,
                            type=ORDER_TYPE_MARKET,
                            quantity=chunk_qty
                        )
                        self.logger.info(f"TWAP Chunk {i+1}/{chunks} executed: {order}")
                        time.sleep(delay)
                    except Exception as e:
                        self.logger.error(f"TWAP chunk {i+1} failed: {e}")
                        continue
                return {"status": "TWAP executed"}
            else:
                self.logger.error("❌ Unsupported order type.")
                return None

        except Exception as e:
            self.logger.error(f"GENERAL ERROR: {e}")
            return None
