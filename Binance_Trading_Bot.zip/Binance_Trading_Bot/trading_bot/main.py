from prompt_toolkit import prompt
from prompt_toolkit.completion import WordCompleter
from bot_logic import BasicBot

# CLI completers for enhanced input
symbol_completer = WordCompleter(["BTCUSDT","ETH"], ignore_case=True)
side_completer = WordCompleter(["BUY", "SELL"], ignore_case=True)
order_type_completer = WordCompleter(["MARKET", "LIMIT", "STOP_MARKET", "OCO", "TWAP"], ignore_case=True)


def main():
    bot = BasicBot()

    while True:
        print("\n🔹 Binance Futures Testnet Trading Bot 🔹")

        symbol = prompt("Enter symbol (e.g., BTCUSDT): ", completer=symbol_completer).upper()
        side = prompt("Buy or Sell? ", completer=side_completer).upper()
        order_type = prompt("Order Type (MARKET / LIMIT / STOP_MARKET / OCO / TWAP): ", completer=order_type_completer).upper()

        qty = float(prompt("Quantity: "))
        price = stop_price = stop_limit_price = None

        if order_type in ["LIMIT", "OCO"]:
            price = prompt("Limit Price: ")
        if order_type in ["STOP_MARKET", "OCO"]:
            stop_price = prompt("Stop Price: ")
        if order_type == "OCO":
            stop_limit_price = prompt("Stop-Limit Price: ")

        result = bot.place_order(
            symbol, side, order_type, qty,
            price=float(price) if price else None,
            stop_price=float(stop_price) if stop_price else None,
            stop_limit_price=float(stop_limit_price) if stop_limit_price else None
        )

        # print(f"\n📋 Result: {result}")

        again = prompt("Do you want to place another order? (yes/no): ").lower()
        if again != "yes":
            print("Exiting the bot. Goodbye!")
            break


if __name__ == "__main__":
    main()


