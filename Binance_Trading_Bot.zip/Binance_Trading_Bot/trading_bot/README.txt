# Binance Futures Testnet Trading Bot

A simplified crypto trading bot built in Python for Binance USDT-M Futures Testnet.
This CLI-based bot allows you to place MARKET, LIMIT, STOP\_MARKET, OCO (simulated), and TWAP orders with logging and user input validation. Optionally, it supports CLI enhancements using `prompt_toolkit` for a modern experience.

---

## 🚀 Features

* ✅ Place MARKET, LIMIT, STOP\_MARKET orders
* ✅ Simulated OCO (One-Cancels-the-Other) order type
* ✅ Simulated TWAP (Time-Weighted Average Price) order type
* ✅ Interactive CLI interface using `prompt_toolkit`
* ✅ Logging of all trades and errors to `bot.log`
* ✅ Error handling for API failures, bad inputs, and missing parameters

---

## 📁 Project Structure

```
crypto_trading_bot/
├── bot_logic.py          # Core trading logic
├── config.py             # API setup and timestamp sync
├── logger.py             # Centralized logging setup
├── main.py               # Entry point with enhanced CLI
├── requirements.txt      # Required Python packages
└── README.txt            # Project overview and setup guide
```

---

## 🔧 Prerequisites

* Python 3.8 or later
* Binance Futures Testnet account
* API Key and Secret from [https://testnet.binancefuture.com](https://testnet.binancefuture.com)

---

## ⚙️ Setup Instructions

### 1. Clone the repository

```bash
mkdir crypto_trading_bot && cd crypto_trading_bot
```

### 2. Create and activate virtual environment

```bash
python -m venv myenv
myenv\Scripts\activate   # Windows
# source myenv/bin/activate   # macOS/Linux
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set up your API keys

Edit `config.py`:

```python
API_KEY = "<your_binance_testnet_api_key>"
API_SECRET = "<your_binance_testnet_api_secret>"
```

---

## 🧪 Using the Bot

### Run the bot

```bash
python main.py
```

### CLI Prompts:

```
Enter symbol (e.g., BTCUSDT): BTCUSDT
Buy or Sell? BUY
Order Type (MARKET / LIMIT / STOP_MARKET / OCO / TWAP): TWAP
Quantity: 0.01
```

For LIMIT and OCO:

* You’ll also be prompted for `Limit Price`
* For OCO: `Stop Price` and `Stop-Limit Price`

TWAP will automatically:

* Split the total quantity into 5 chunks
* Place MARKET orders every 5 seconds

### Exit the bot:

```
Do you want to place another order? (yes/no): no
```

---

## 📝 Logging

* All API requests, responses, and errors are logged to `bot.log`
* You can inspect this file to verify orders or debug issues

---

## 🆘 Troubleshooting

| Issue                                                 | Solution                                                       |
| ----------------------------------------------------- | -------------------------------------------------------------- |
| `ModuleNotFoundError: binance`                        | Run: `pip install python-binance`                              |
| `Timestamp for this request is outside of recvWindow` | Ensure timestamp sync logic exists in `config.py`              |
| `AttributeError: _get_timestamp_offset`               | Use latest `python-binance` or set `recvWindow=60000` manually |

---

## 📦 Optional Enhancements

* Add configurable chunks and delay to TWAP
* Extend to Spot market or leverage WebSockets
* Add a frontend using Flask or Streamlit

---

Happy Trading! 🚀
