from binance.client import Client
import time
import requests

API_KEY = "<your_binance_testnet_api_key>"
API_SECRET = "<your_binance_testnet_api_secret>"

def get_server_time_offset():
    try:
        server_time = requests.get("https://testnet.binancefuture.com/fapi/v1/time").json()["serverTime"]
        local_time = int(time.time() * 1000)
        return server_time - local_time
    except Exception as e:
        print("⚠️ Failed to fetch Binance server time:", e)
        return 0

def get_binance_client():
    client = Client(API_KEY, API_SECRET)
    
    # ✅ Testnet setup
    client.API_URL = 'https://testnet.binancefuture.com'
    client.FUTURES_URL = 'https://testnet.binancefuture.com/fapi'

    # ✅ Adjust recvWindow globally
    client.FUTURES_DEFAULT_RECV_WINDOW = 10000

    # ✅ Apply timestamp offset manually
    client._timestamp_offset = get_server_time_offset()

    return client
